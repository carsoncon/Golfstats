from database import Base
from sqlalchemy import Column, Integer, String, Float

class PlayerStats(Base):
    __tablename__ = "player_stats"
    
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, index=True)
    year = Column(Integer, index=True)
    strokes_gained = Column(Float)
    driving_distance = Column(Float)
    putting_avg = Column(Float)
