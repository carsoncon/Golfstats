from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from database import SessionLocal
from models import PlayerStats

router = APIRouter()

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@router.get("/players")
def get_players(db: Session = Depends(get_db)):
    return db.query(PlayerStats).all()

@router.get("/player/{name}")
def get_player(name: str, db: Session = Depends(get_db)):
    return db.query(PlayerStats).filter(PlayerStats.name == name).first()
